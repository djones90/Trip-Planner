from django.urls import path
from . import views

urlpatterns = [
path('', views.home),
path('register', views.register),
path('login', views.login),
path('success', views.success),
path('new', views.new),
path('create', views.create),
path('<int:trip_id>/edit', views.edit),
path('<int:trip_id>/update', views.update),
path('<int:trip_id>/delete', views.delete),
path('<int:trip_id>', views.trip_details),
path('logout', views.logout),
]
