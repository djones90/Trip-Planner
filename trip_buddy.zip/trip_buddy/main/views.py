from django.shortcuts import render, redirect
from . models import *
from django.contrib import messages
import bcrypt

# Create your views here.

def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        # validate input 
        errors = User.objects.user_validator(request.POST)
        if len(errors) != 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/')
        hashed_pw = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        new_user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = hashed_pw,
        )
        request.session['logged_user'] = new_user.id
        return redirect('/success')
    return redirect('/')

def login(request):
    if request.method == 'POST':
        errors = User.objects.log_validator(request.POST)
        if len(errors) != 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/')
        this_user = User.objects.get(email = request.POST['email'])
        request.session['logged_user'] = this_user.id
        return redirect('/success')
    return redirect('/')

def success(request):
    #if 'logged_user' not in request.session:
    #    return redirect('/')
    
    user = User.objects.get(id=request.session['logged_user'])
    context = {
        'logged_user' : User.objects.get(id=request.session['logged_user']),
        #'all_trips' : Trip.objects.all(),
        'user_trips': Trip.objects.all()
        #'recent_trips' : Trip.objects.order_by('-created_at')
    }
    return render(request, 'user_dashboard.html', context)

def logout(request):
    request.session.flush()
    return redirect('/')

#@login_required
def new(request):
    if 'logged_user' not in request.session:
        return redirect('/')

    user = User.objects.get(id=request.session['logged_user'])
    context = {
        'logged_user' : User.objects.get(id=request.session['logged_user']),
        'all_trips' : Trip.objects.all(),
        #'recent_trips' : Trip.objects.order_by('-created_at')
    }
    
    return render(request, 'new_trip.html', context)

def create(request):
#    if request.method == 'POST':
    if 'logged_user' not in request.session:
        messages.error(request, 'Please register or log in first!')
        return redirect('/')
    
    if request.method == 'POST':
        errors = Trip.objects.trip_validator(request.POST)
    
    if errors:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/new')
    
    user = User.objects.get(id=request.session['logged_user'])
    Trip.objects.create(
        user = user,
        destination = request.POST['destination'],
        start_date = request.POST['start_date'],
        end_date = request.POST['end_date'],
        plan = request.POST['plan']
    )
    
    return redirect('/success')
        
def delete(request, trip_id):
    to_delete = Trip.objects.get(id=trip_id)
    to_delete.delete()
    return redirect('/success')

def trip_details(request, trip_id):
    if 'logged_user' not in request.session:
        return redirect('/')
    
    user = User.objects.get(id=request.session['logged_user'])
    one_trip = Trip.objects.get(id=trip_id)
    context = {
        'trip': one_trip,
        'user': user
    }
    
    return render(request, 'trip_details.html', context)

def edit(request, trip_id):
    if 'logged_user' not in request.session:
        return redirect('/')

    user = User.objects.get(id=request.session['logged_user'])
    one_trip = Trip.objects.get(id=trip_id)
    context = {
        'user': user,
        'trip': one_trip
    }
    return render(request, 'edit_trip.html', context)

def update(request, trip_id):
    if 'logged_user' not in request.session:
        return redirect('/')
    
    errors = Trip.objects.trip_validator(request.POST)
    
    if errors:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f'/{trip_id}/update')
    #if request.method == "POST":
    else:
        user = User.objects.get(id=request.session['logged_user'])
        to_update = Trip.objects.get(id=trip_id)
        to_update.destination = request.POST['destination']
        to_update.start_date = request.POST['start_date']
        to_update.end_date = request.POST['end_date']
        to_update.plan = request.POST['plan']
        to_update.save()

        return redirect('/success')



# def add_trip(request):
    
#     if 'logged_user' not in request.session:
#         messages.error(request, 'Please register or log in first!')
#         return redirect('/')
    
#     if request.method == "POST":
#         trip_errors = Trip.objects.trip_validator(request.POST)
#         errors = list(trip_errors.values())
        
#     if errors:
#         for error in errors:
#             messages.error(request, error)
#         return redirect('/new')
    
#     user = User.objects.get(id=request.session ['logged_user'])
    
#     context = {
#         'user': user
#     }
#     return render(request, 'user_dashboard.html', context)